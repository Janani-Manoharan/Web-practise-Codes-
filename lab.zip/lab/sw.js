//console.log("Connection Successful");
self.skipWaiting();
self.addEventListener('install',event => {
    event.waitUntil (
      caches.open('temp').then(
          cache => {
              return cache.addAll(['/index.html','/page1.htm','/404.jpg'])
          }
      )
    );
})

self.addEventListener('fetch',event => {
    event.respondWith(
        caches.match(event.request).then(Response => {
            if(Response != null){
                return Response;
            }
            return caches.match('/404.jpg');
        })
    )
})
